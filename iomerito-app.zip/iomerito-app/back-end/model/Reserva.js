const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let Reserva = new Schema({
  name: {
    type: String
  },
  email: {
    type: String
  },
  phone: {
    type: Number
  },
  date: {
    type: Date
  },
  time: {
    type: String
  },
  people: {
    type: Number
  },
  message: {
    type: String
  }
},{
    collection: 'reserva'
});

module.exports = mongoose.model('Reserva', Reserva);