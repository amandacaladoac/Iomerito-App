const express = require('express');
const app = express();
const reservaRoutes = express.Router();

let Reserva = require('../model/Reserva');

// api to add reserva
reservaRoutes.route('/add').post(function (req, res) {
  let reserva = new Reserva(req.body);
  reserva.save()
  .then(reserva => {
    res.status(200).json({'status': 'success','mssg': 'reserva added successfully'});
  })
  .catch(err => {
    res.status(409).send({'status': 'failure','mssg': 'unable to save to database'});
  });
});

// api to get reservas
reservaRoutes.route('/').get(function (req, res) {
  Reserva.find(function (err, reservas){
    if(err){
      res.status(400).send({'status': 'failure','mssg': 'Something went wrong'});
    }
    else {
      res.status(200).json({'status': 'success','reservas': reservas});
    }
  });
});

// api to get reserva
reservaRoutes.route('/reserva/:id').get(function (req, res) {
  let id = req.params.id;
  Reserva.findById(id, function (err, reserva){
    if(err){
      res.status(400).send({'status': 'failure','mssg': 'Something went wrong'});
    }
    else {
      res.status(200).json({'status': 'success','reserva': reserva});
    }
  });
});

// api to update route
reservaRoutes.route('/update/:id').put(function (req, res) {
    Reserva.findById(req.params.id, function(err, reserva) {
    if (!reserva){
      res.status(400).send({'status': 'failure','mssg': 'Unable to find data'});
    } else {
        reserva.name = req.body.name;
        reserva.email = req.body.email;
        reserva.phone = req.body.phone;
        reserva.date = req.body.date;
        reserva.time = req.body.time;
        reserva.people = req.body.people;
        reserva.message = req.body.message;

        reserva.save().then(business => {
          res.status(200).json({'status': 'success','mssg': 'Update complete'});
      })
    }
  });
});

// api for delete
reservaRoutes.route('/delete/:id').delete(function (req, res) {
  Reserva.findByIdAndRemove({_id: req.params.id}, function(err,){
    if(err){
      res.status(400).send({'status': 'failure','mssg': 'Something went wrong'});
    }
    else {
      res.status(200).json({'status': 'success','mssg': 'Delete successfully'});
    }
  });
});

module.exports = reservaRoutes;